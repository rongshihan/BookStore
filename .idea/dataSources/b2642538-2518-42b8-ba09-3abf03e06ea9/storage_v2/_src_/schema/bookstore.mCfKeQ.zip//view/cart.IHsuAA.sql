create view cart as
select `bookstore`.`orders`.`user_id`     AS `user_id`,
       `bookstore`.`orders`.`ID`          AS `ID`,
       `bookstore`.`orders`.`book_id`     AS `book_id`,
       `bookstore`.`orders`.`book_name`   AS `book_name`,
       `bookstore`.`book`.`price`         AS `price`,
       `bookstore`.`orders`.`book_number` AS `book_number`,
       `bookstore`.`orders`.`goods_price` AS `goods_price`,
       `bookstore`.`orders`.`time`        AS `time`,
       `bookstore`.`book`.`path`          AS `path`,
       `bookstore`.`orders`.`status`      AS `status`
from `bookstore`.`orders`
         join `bookstore`.`book`;

